Simple CRM make with Python.
